export const AUTH_TOKEN = 'auth_token'
export const AUTH = 'auth'
export const ADMIN = 1
