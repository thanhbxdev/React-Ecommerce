import React from 'react'
const getPhoto = (id) => {
  return `http://localhost:3333/api/product/photo/${id}`
}
export default getPhoto
