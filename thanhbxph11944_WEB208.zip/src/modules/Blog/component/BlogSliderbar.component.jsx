import React from 'react'
import BlogSingleComponent from './BlogSingle.component'

function BlogSliderbarComponent() {
  return (
    <div className="col-xs-12 col-md-8 row">
      <BlogSingleComponent />
    </div>
  )
}
export default BlogSliderbarComponent
