import React from 'react'
import { Redirect, Route, Switch } from 'react-router-dom'
import ProductListPage from './pages/ProductList.page'
import MasterLayout from '../../layout/Master.layout'
import ProductDetailPage from './pages/ProductDetail.page'
import ProductCate from './pages/ProductCate'

export const ProductRoutesPath = {
  root: '/product',
  detail: '/product/:id/detail',
  cate: '/product/cate/:id',
  list: '/product/list',
  toDetail: (id) => `/product/${id}/detail`
}

function ProductRoutes(props) {
  return (
    <MasterLayout>
      <Switch>
        <Route path={ProductRoutesPath.list} exact>
          <ProductListPage {...props} />
        </Route>
        <Route path={ProductRoutesPath.detail} exact>
          <ProductDetailPage {...props} />
        </Route>
        <Route path={ProductRoutesPath.cate} exact>
          <ProductCate />
        </Route>
      </Switch>
    </MasterLayout>
  )
}

export default ProductRoutes
