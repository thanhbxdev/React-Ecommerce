import React from 'react'
import banner from '../../../assets/images/banner/shop-sidebar.jpg'
import WidgetContentComponent from './WidgetContent.component'
import { Link } from 'react-router-dom'

function SidebarShopComponent() {
  return (
    <div className="col-xs-12 col-md-3 sidebar-shop">
      <div className="sidebar-product-categori">
        <div className="widget-title">
          <h3>PRODUCT CATEGORIES</h3>
        </div>
        <WidgetContentComponent />
        <div className="sidebar-single-banner">
          <Link to="/">
            <img src={banner} alt="Banner" />
          </Link>
        </div>
      </div>
    </div>
  )
}

export default SidebarShopComponent
