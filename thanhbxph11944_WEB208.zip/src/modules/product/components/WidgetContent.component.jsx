import React, { useEffect, useState } from 'react'
import ProductAPI from '../../../callApi/productApi'
import CategoryAPI from '../../../callApi/categoryAPI'
import { NavLink } from 'react-router-dom'

function WidgetContentComponent() {
  const [categories, setCategories] = useState([])
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(false)
  useEffect(() => {
    const getProduct = async () => {
      try {
        setLoading(true)
        const { data: categories } = await CategoryAPI.getAll()
        const { data: products } = await ProductAPI.getAll()
        setProducts(products)
        setCategories(categories)
      } catch (error) {
        console.log(error)
      } finally {
        setLoading(false)
      }
    }
    getProduct()
  }, [])
  return (
    <div className="widget-content">
      <ul className="product-categories">
        {categories.map((cate, index) => (
          <li className="cat-item" key={index}>
            <NavLink to={`/product/cate/${cate._id}`} className="text-black">
              {cate.name}
            </NavLink>
            <span className="count">
              ({products.filter((prd) => prd.category === cate._id).length})
            </span>
          </li>
        ))}
      </ul>
    </div>
  )
}

export default WidgetContentComponent
