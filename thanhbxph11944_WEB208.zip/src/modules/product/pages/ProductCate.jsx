import React, { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import SidebarShopComponent from '../components/SidebarShop.component'
import CategoryAPI from '../../../callApi/categoryAPI'
import ProductAPI from '../../../callApi/productApi'

function ProductCate() {
  const { id } = useParams()
  const [categories, setCategories] = useState([])
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(false)
  useEffect(() => {
    const getProduct = async () => {
      try {
        setLoading(true)
        const { data: categories } = await CategoryAPI.getAll()
        // const { data: products } = await ProductAPI.getAll()
        // setProducts(products)
        setCategories(categories)
      } catch (error) {
        console.log(error)
      } finally {
        setLoading(false)
      }
    }
    getProduct()
  }, [])
  const catename = categories.find((cate) => cate._id === id)
  console.log(catename.name)
  return (
    <div>
      <div className="breadcrumbs-container">
        <div className="container">
          <div className="row">
            <div className="col-sm-12">
              <nav className="woocommerce-breadcrumb">
                <Link to="/">Home</Link>
                <span className="separator">/</span>
                {catename.name}
              </nav>
            </div>
          </div>
        </div>
      </div>
      <div className="shop-page-wraper container">
        <div className="container">
          <div className="row">
            <SidebarShopComponent />
            {/*<ShopContentComponent products={...products} />*/}
          </div>
        </div>
      </div>
    </div>
  )
}
export default ProductCate
